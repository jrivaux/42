/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/06 15:41:39 by jrivaux           #+#    #+#             */
/*   Updated: 2014/01/06 14:19:40 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <string.h>
#include "libft.h"

char		*ft_strtrim(char const *s)
{
	int		i;
	int		y;
	char	*s1;

	i = 0;
	y = 0;
	s1 = (char*)malloc(ft_strlen(s) + 1 * sizeof (*s1));
	if (s1 == NULL)
		return (NULL);
	while ((s[i] == ' ') || (s[i] == '\n') || (s[i] == '\t'))
		i++;
	while (s[i])
	{
		s1[y] = s[i];
		i++;
		y++;
	}
	i--;
	while ((s[i] == ' ') || (s[i] == '\n') || (s[i] == '\t'))
	{
		i--;
		y--;
	}
	s1[y] = '\0';
	return (s1);
}
