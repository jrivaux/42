/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_echo.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/25 17:31:01 by jrivaux           #+#    #+#             */
/*   Updated: 2014/02/28 18:06:24 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <libft.h>
#include "ft_sh.h"

void	ft_echo(char **tab)
{
	int	i;
	int	j;

	i = 1;
	if (tab[1])
	{
		while (tab[i] != NULL)
		{
			//	ft_option(tab, i);
			j = 0;
			while (tab[i][j] != 0 && tab[i][j] != '\\')
				j++;
		//	j++;
			while (tab[i][j + 1] != '\0')
			{
				tab[i][j] = tab[i][j + 1];
				j++;
			}
			tab[i][j] = 0;
			ft_option(tab[i]);
		//	write(1, tab[i], ft_strlen(tab[i]));
	//		write(1, " ", 1);
			i++;
		}
	}
	write(1, "\n", 1);
}

void		ft_option(char *str)
{
	int		j;

	j = 0;
	while (str[j] != '\\' && str[j] != 0)
		j++;
	//if (ft_strncmp("n", str + (j + 1), 0) == 0)
	if (str[j] == '\\' && str[j + 1] == 'n')
	{
			write(1, str, ft_strlen(str)- 2);
	//		write(1, "caca\n", 5);
			write(1, "\n", 1);
	}
	else
		write(1, str, ft_strlen(str)+ 1);
}
