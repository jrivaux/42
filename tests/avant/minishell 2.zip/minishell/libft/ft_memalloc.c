/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memalloc.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/06 15:30:55 by jrivaux           #+#    #+#             */
/*   Updated: 2014/01/06 13:16:30 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "libft.h"

void		*ft_memalloc(size_t size)
{
	char	*str;

	str = (char*)malloc(size * sizeof(*str));
	if (str == NULL)
		return (NULL);
	ft_memset(str, 0, size);
	return ((void*)str);
}
