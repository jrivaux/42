/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/26 10:41:07 by jrivaux           #+#    #+#             */
/*   Updated: 2013/12/27 10:11:16 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

unsigned int	ft_strlen(const char *s);
int				ft_putchar(char c);
int				ft_putstr(const char *s);
int				ft_putsigned(int n, int k);
int				ft_putunsigned(unsigned int n, int k, unsigned int b);
int				ft_putpointer(unsigned long n, int k);
int				ft_printf(const char *format, ...);

#endif /* FT_PRINTF_H */
