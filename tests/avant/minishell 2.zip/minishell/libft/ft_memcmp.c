/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/06 12:23:50 by jrivaux           #+#    #+#             */
/*   Updated: 2014/01/06 13:19:08 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int			ft_memcmp(const void *s1, const void *s2, size_t n)
{
	char	*dest;
	char	*src;
	size_t	i;

	i = 0;
	dest = (char*)s1;
	src = (char*)s2;
	while (n > 0)
	{
		while (dest[i] == src[i])
		{
			if (dest[i] == '\0')
				return (dest[i] - src[i]);
			i++;
			n--;
		}
		return (dest[i] - src[i]);
	}
	return (0);
}
