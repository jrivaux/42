/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/25 15:46:21 by jrivaux           #+#    #+#             */
/*   Updated: 2014/01/06 13:22:18 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void		*ft_memmove(void *s1, const void *s2, size_t n)
{
	size_t	i;
	char	*src;
	char	*dest;

	i = 0;
	src=(char *)s1;
	dest=(char *)s2;
	while (n > 0)
	{
		src[n] = dest[n];
		n--;
	}
	src[n] = dest[n];
	return (src);
}
