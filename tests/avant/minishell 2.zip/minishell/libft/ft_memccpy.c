/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/24 10:19:59 by jrivaux           #+#    #+#             */
/*   Updated: 2014/01/23 19:21:28 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void		*ft_memccpy(void *s1, const void *s2, int c, size_t n)
{
	char	*dest;
	char	*src;
	size_t	i;

	i = 0;
	dest = (char *)s1;
	src = (char *)s2;
	while (i < n && src[i] != c)
	{
		dest[i] = src[i];
		i++;
	}
	if (src[i] == c)
	{
		dest[i] = src[i];
		return ((char *)dest + i + 1);
	}
	return (NULL);
}
