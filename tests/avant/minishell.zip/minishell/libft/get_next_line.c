/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/05 10:35:39 by jrivaux           #+#    #+#             */
/*   Updated: 2014/01/23 19:42:13 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int		ft_check_lines(char *tmp, char **line)
{
	int			i;
	int			counter;
	static int	start = 0;

	counter = 0;
	i = 0;
	while ((tmp[start + i] != '\n') && (tmp[start + i]))
	{
		counter++;
		i++;
	}
	if (!(tmp[start + i]))
		return (0);
	*line = ft_strnew(ft_strlen(tmp));
	ft_strncat(*line, (tmp + start), counter);
	i++;
	start += i;
	return (1);
}

char	*ft_alloc_tmp(char *tmp, int n)
{
	char	*tmp2;

	tmp2 = ft_strnew(n + ft_strlen(tmp));
	tmp2 = ft_strcat(tmp2, tmp);
	return (tmp2);
}

int		get_next_line(int const fd, char **line)
{
	char		buf[BUFF_SIZE + 1];
	static char	*tmp = NULL;
	int			i;

	i = 0;
	if (fd == -1)
		return (-1);
	if (!tmp)
	{
		tmp = ft_strnew(1);
		while ((i = (read(fd, buf, BUFF_SIZE))) > 0)
		{
			buf[BUFF_SIZE] = '\0';
			tmp = ft_alloc_tmp(tmp, i);
			ft_strncat(tmp, buf, BUFF_SIZE);
		}
		if (i == -1)
			return (i);
	}
	return (ft_check_lines(tmp, line));
}

