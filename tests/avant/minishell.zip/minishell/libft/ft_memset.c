/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/11/25 20:00:16 by jrivaux           #+#    #+#             */
/*   Updated: 2014/01/06 13:23:29 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>

void				*ft_memset(void *b, int c, size_t n)
{
	unsigned char	charact;
	char			*ch;

	ch = b;
	charact = c;
	while (n > 0)
	{
		*ch = charact;
		ch++;
		n--;
	}
	return (b);
}
