/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/16 02:06:41 by jrivaux           #+#    #+#             */
/*   Updated: 2014/01/06 14:13:07 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "libft.h"

char		*ft_strmap(char const *s, char (*f)(char))
{
	size_t	sizeofs;
	size_t	index;
	char	*str;

	index = 0;
	sizeofs = ft_strlen(s);
	str = malloc(sizeof(char) * (sizeofs + 1));
	while (index < sizeofs)
	{
		str[index] = f(s[index]);
		index++;
	}
	return (str);
}
