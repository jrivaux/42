/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_striteri.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/16 02:01:39 by jrivaux           #+#    #+#             */
/*   Updated: 2014/01/06 14:10:26 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void				ft_striteri(char *str, void (*f) (unsigned int, char*))
{
	unsigned int	index;

	index = 0;
	while (*str)
	{
		f(index, str);
		index++;
		str++;
	}
}
