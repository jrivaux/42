/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strsub.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/06 15:14:48 by jrivaux           #+#    #+#             */
/*   Updated: 2014/01/23 19:39:01 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdlib.h>

char	*ft_strsub(char const *s, unsigned int start, size_t len)
{
	char	*out;

	if (s == NULL)
		return (NULL);
	out = (char *)malloc(sizeof(*s) * len + 1);
	if (out == NULL)
		return (NULL);
	ft_strncpy(out, (s + start), len + 1);
		return ((char *)out);
}
