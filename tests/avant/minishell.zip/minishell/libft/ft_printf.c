/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jrivaux <jrivaux@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2013/12/26 10:38:42 by jrivaux           #+#    #+#             */
/*   Updated: 2014/01/23 19:23:25 by jrivaux          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdarg.h>
#include <unistd.h>
#include "ft_printf.h"

static int	ft_printarg(char c, va_list *ap)
{
	if (c == 'c')
		return (ft_putchar(va_arg(*ap, int)));
	else if (c == 's')
		return (ft_putstr(va_arg(*ap, char *)));
	else if (c == 'd' || c == 'i')
		return (ft_putsigned(va_arg(*ap, int), 0));
	else if (c == 'u')
		return (ft_putunsigned(va_arg(*ap, unsigned int), 0, 10));
	else if (c == 'o')
		return (ft_putunsigned(va_arg(*ap, unsigned int), 0, 8));
	else if (c == 'x')
		return (ft_putunsigned(va_arg(*ap, unsigned int), 0, 16));
	else if (c == 'p')
	{
		ft_putstr("0x");
		return (ft_putpointer(va_arg(*ap, unsigned long), 2));
	}
	else if (c == '%')
		return (ft_putchar('%'));
	else if (c == 'Z')
		return (ft_putchar('Z'));
	return (0);
}

int			ft_printf(const char *format, ...)
{
	va_list		ap;
	int			i;
	int			j;
	int			k;

	if (!format)
		return (0);
	va_start(ap, format);
	i = 0;
	j = 0;
	k = 0;
	while (format[i])
	{
		if (format[i++] == '%')
		{
			write(1, format + j, i - j - 1);
			k += ft_printarg(format[i], &ap) + i - j - 1;
			j = ++i;
		}
	}
	write(1, format + j, i - j);
	va_end(ap);
	return (k + i - j);
}

